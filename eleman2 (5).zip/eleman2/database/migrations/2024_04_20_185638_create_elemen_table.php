<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateElemenTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('elemen', function (Blueprint $table) {
            $table->id();
            $table->timestamp('giris'); // Assuming you may want them to be nullable
            $table->timestamp('cikis');
            $table->string('sube', 191); // Optional: specify the length if necessary
            $table->string('adi', 191); // Optional: specify the length if necessary
            $table->integer('kod');
            $table->timestamps(); // This adds created_at and updated_at columns
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('elemen');
    }
}
