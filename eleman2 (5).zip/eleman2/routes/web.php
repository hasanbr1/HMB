<?php

use App\Http\Controllers\elemanlar;
use Illuminate\Support\Facades\Route;
use App\Models\Eleman;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
})->name('login');


Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashbord', function () {
        return view('dashbord');
    });
    Route::get('/bilgiler', function () {
        return view('bilgiler');
    })->name('bilgiler');
   
  
});

Route::get('/duzeltme', function () {
    $uniqueNames = Eleman::select('adi')->distinct()->pluck('adi');
    return view('duzeltme')->with('uniqueNames', $uniqueNames);
})->name('duzeltmesi');

Route::get('/eleman', function () {
    return view('eleman');
})->name('ekle');

Route::get('/sube', function () {
    return view('sube');
})->name('subev');
Route::get('/gcduzeltme', function () {
    $uniqueElements = Eleman::select('adi', 'giris')->distinct()->get();
    return view('gcduzeltme')->with(['uniqueElements' => $uniqueElements]);
})->name('gcduzeltmevi');

Route::post('/gcduzeltme',[elemanlar::class, 'gcduzeltme'])->name('gcduzeltme');
Route::post('/ekleme',[elemanlar::class, 'store'])->name('ekleme');
Route::post('/sube',[elemanlar::class, 'subeler'])->name('subem');
Route::get('/bilgiler',[elemanlar::class, 'showSelectSube']);
Route::post('/',[elemanlar::class, 'giris'])->name('giris');
Route::get('/bilgiler',[elemanlar::class, 'indexbilgi']);
Route::get('/dashbord', [elemanlar::class, 'index'])->name('dash');
Route::post('/bilgiler',[elemanlar::class, 'sift'])->name('sift');

Route::post('/duzeltme',[elemanlar::class, 'elemanb'])->name('duzeltmebilgi');
Route::get('/subeler',[elemanlar::class, 'subelerviwe'])->name('subeler');
Route::get('/muhasabe',[elemanlar::class, 'muhasabe'])->name('muhasabe');

