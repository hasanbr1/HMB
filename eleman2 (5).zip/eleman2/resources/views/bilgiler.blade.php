<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 ,maximum-scale=1">
    <title>Shift Manager</title>
    <link rel="stylesheet" href="css/bilgiler.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        .hidden {
            display: none;
        }
    </style>
    <!-- Include jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
    // Declare showView globally
    function showView(viewType) {
        const dailyView = document.getElementById('dailyView');
        const monthlyView = document.getElementById('monthlyView');
        const giris= document.getElementById('giris');
        if (viewType === 'daily') {
            dailyView.style.display = 'block';
            monthlyView.style.display = 'none';
            giris.style.display = 'none';
        } else if (viewType === 'monthly') {
            dailyView.style.display = 'none';
            monthlyView.style.display = 'block';
            giris.style.display = 'none';
        }else if(viewType === 'giris'){
            dailyView.style.display = 'none';
            monthlyView.style.display = 'none';
            giris.style.display = 'block';
        }
    }

    $(document).ready(function() {
        const dailyViewButton = document.getElementById('dailyViewButton');
        const monthlyViewButton = document.getElementById('monthlyViewButton');
        const girisButton = document.getElementById('girisb');

        dailyViewButton.addEventListener('click', function() {
            showView('daily');
            monthlyViewButton.innerHTML="unchecked";
        });

        monthlyViewButton.addEventListener('click', function() {
            showView('monthly');
        });
        girisButton.addEventListener('click', function() {
            showView('giris');
        });
        const monthlyTotals = {};
        document.querySelectorAll('#dailyView table').forEach(table => {
            const dateText = table.querySelector('th').textContent;
            const monthYear = dateText.split('-')[0].trim()+'/'+dateText.split('-')[1].trim();

            table.querySelectorAll('tbody tr').forEach(row => {
                const hoursMinutes = row.cells[2].textContent.trim().split(':');
                const hours = parseInt(hoursMinutes[0]);
                const minutes = parseInt(hoursMinutes[1]);
                const salary = parseFloat(row.cells[3].textContent);

                if (!monthlyTotals[monthYear]) {
                    monthlyTotals[monthYear] = { totalHours: 0, totalMinutes: 0, totalSalary: 0 };
                }

                monthlyTotals[monthYear].totalHours += hours;
                monthlyTotals[monthYear].totalMinutes += minutes;
                monthlyTotals[monthYear].totalSalary += salary;
            });
        });

        const monthlyBody = document.querySelector('#monthlyView tbody');
        Object.entries(monthlyTotals).forEach(([monthYear, data]) => {
            const row = document.createElement('tr');
            const totalHours = data.totalHours + Math.floor(data.totalMinutes / 60);
            const remainingMinutes = data.totalMinutes % 60;
            row.innerHTML = `<td>${monthYear}</td><td>${totalHours}h ${remainingMinutes}m</td><td>${data.totalSalary.toFixed(2)}</td>`;
            monthlyBody.appendChild(row);
        });
    });
    </script>



</head>
<body>
   
   <div id="head">

        <div class="radio-inputs">
  <label class="radio">
    <input type="radio" class="y"id="dailyViewButton" name="radio" onclick="showView('daily')" style="margin:0%;" >
    <span class="name">Günlük</span>
  </label>
  <label class="radio">
 <input type="radio" class="y" id="monthlyViewButton" name="radio" onclick="showView('monthly')" > 
    <span class="name">Aylık</span>
  </label>

  <label class="radio">
 <input type="radio" class="y" id="girisb" name="radio" onclick="showView('giris')" >
    <span class="name">Giriş Sayfası</span>
  </label>


       
</div>
</div>


    
    <!-- Navigation for views -->
    <div id="giris"  class="card">
    <div class="blob"> </div>
    <div class="bg">
 
        <form id="shiftForm" action="{{Route('sift')}}" method="POST">
            @csrf
            <h5>mesaiye başla</h5>
            @foreach($userEntries as $date => $entries)
            <input type="text" name="adi" value="{{$entries->first()->adi}}" style="display:none; " class="btms">
            <input type="text" name="kod" value="{{$entries->first()->kod}}" style=" display:none; " class="btms">
            @endforeach
            <select id="sube-select" name="sube">
                <option value="">Şube Seç</option>
                @if(session('subes'))
                    @foreach(session('subes') as $sube)
                        <option value="{{ $sube }}">{{ $sube}}</option>
                    @endforeach
                @endif
             
            </select><br>
           
       
            <button type="submit" onclick="saveShift()" id="shiftStartButton" name="shiftStartButton" value="shiftStartButton">Başla</button>
            <hr>
            <h5>mesaiyi bittir</h5>
          
            <button type="submit" onclick="saveShift()" id="shiftEndButton" name="shiftEndButton">Bitir</button>
             
        </form>
       
        </div>
    </div>

    <!-- Daily View -->
    <div id="dailyView" class="hidden">
        @foreach($userEntries as $date => $entries)
        @if($date != '1999-12-12')
            <table>
                <thead>
                    <tr>
                        <th colspan="4">{{ $date }}</th>
                    </tr>
                    <tr>
                        <th>Giriş Saati</th>
                        <th>Çıkış Saati</th>
                        <th>Toplam</th>
                        <th>Maas</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($entries as $entry)
                   
                        <tr>
                            <td>{{ $entry->formatted_giris }}</td>
                            <td>{{ $entry->formatted_cikis }}</td>
                            <td>  @if($entry->minutes_worked>=60)
                       {{ $entry->minutes_worked/60}} :{{$entry->minutes_worked%60  }}
                       @else
                      0: {{$entry->minutes_worked}}</td>
                            @endif
                            <td> {{ $entry->maas_total }}</td>
                        </tr>
                      
                    @endforeach
                </tbody>
            </table>
            @endif
        @endforeach
       
    </div>

    <!-- Monthly View -->
    <div id="monthlyView" class="hidden">
        <table>
            <thead>
                <tr>
                    <th>Ay</th>
                    <th>Toplam saat</th>
                    <th>Maas</th>
                </tr>
            </thead>
            <tbody>
                <!-- Monthly totals will be populated dynamically using JavaScript -->
            </tbody>
        </table>
    </div>
   
<script>
   
    $(document).ready(function() {
        $('.hamburger').click(function(event) {
            event.stopPropagation();  // Stop propagation to prevent closing when clicking inside the sidebar
            $('#sidebar').toggle('slow');
        });

        $(document).click(function(event) {
            if (!$(event.target).closest('#sidebar, .hamburger').length) {
                $('#sidebar').hide('slow');
            }
        });
    });

</script>
</body>
</html>
