<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/duzeltme.css">

        <style>
           button {
                margin-left: 6%;
            }
            body{
                margin: 0%;
            }
            #form{
               width: 90%;
            }
            @media (min-width: 768px) {
    #form {
        flex-direction: column;
        width: 35%; /* Increase width for smaller screens */
        height: auto; /* Make height auto for better flexibility */
        margin-left: 30%;
    }
    button {
              
            }
}
        </style>
    </head>
    <body class="antialiased">


    <div id="form">
      
        <form action="{{Route('gcduzeltme')}}" method="post">
            @csrf
            <label for="eleman-select">Eleman ve Tarih Seçin:</label>
<select id="eleman-select" name="eleman">
    <option value="">Eleman ve Tarih Seç</option>
    @foreach ($uniqueElements as $element)
    @if($element->giris != '1999-12-12 00:00:00')
        <option value="{{$element->adi}}|{{$element->giris}}">{{$element->adi}} - {{$element->giris}}</option>
    @endif
    @endforeach
</select>
            <button type="submit" name="btn2" >Seç</button>
            <button ><a href="{{Route('dash')}}">Geri</a></button>
            </form>
            <div id="con">
          
            <form action="{{Route('gcduzeltme')}}" method="post" >
            @csrf

    <label for="adi">çıkış tarihi:</label>
    <input type="text" name="ecikis" id="" readonly value="{{ $gcikis->cikis ?? 'çıkış yapılmadı'}}">
    <label for="adi">Adi:</label>
     <input type="text" name="adi" id="" value="{{ $gcikis->adi ?? ''}} ">
     <label for="adi">giriş tarihi:</label>
     <input type="text" name="giris" id="" value="{{ $gcikis->giris ?? ''}}" >
     <label for="adi"> Yeni çıkış tarihi:</label>
     <input type="datetime-local"  name="ycikis" id="">

    <button type="submit" name="btn1" >Kaydet</button>
    <button type="submit" name="btn3" style="float:left;" >Sil</button>
            </form>
           
        </div>

        </div>
       
        </div>
    </body>
    
</html>
</body>
</html>