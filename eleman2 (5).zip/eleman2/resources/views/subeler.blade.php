<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Monthly Hours and Salaries</title>
    <link rel="stylesheet" href="css/x.css">
</head>
<body>
    <style>
        body{
            text-align: center;
        }
    </style>
<div class="container mt-5">

            <h1 style="color: orange; display: inline">DÖNER</h1>
            <h1 style="color: yellow;  display: inline">XL</h1>
      
    <select id="branchSelect" onchange="filterByBranch()" style="margin-bottom: 20px; width: 100%;">
        <option value="">Select Branch</option>
        @foreach ($branches as $sube => $months)
            @if($sube != null)
                <option value="{{ $sube }}">{{ $sube }}</option>
            @endif
        @endforeach
    </select>
    <div id="branchesContainer">
        @php
        $totalPayroll = 0;
        @endphp
        @foreach ($branches as $sube => $months)
        @if($sube != null)
        <div class="branch-div" id="{{ $sube }}" style="display: none;">
            <table class="table table-bordered">
                <thead class="branch-header">
                    <tr>
                        <th colspan="5" style="background: red;">{{ $sube }}</th>
                    </tr>
                </thead>
                @foreach ($months as $year_month => $employees)
                    <thead>
                        <tr>
                            <th colspan="5">{{ $year_month }}</th>
                        </tr>
                        <tr>
                            <th>Eleman Adı</th>
                            <th>Saat toplamı</th>
                            <th>Gün toplamı</th>
                            <th>Saat başına Maas</th>
                            <th>Maas toplamı</th>
                        </tr>
                    </thead>
                    <tbody>
                    @foreach ($employees as $employeeName => $employeeData)
                    
                        <tr>
                            <td>{{ $employeeName }}</td>
                            <td>{{ $employeeData['total_hours'] }}</td>
                            <td>{{ $employeeData['total_days'] }}</td>
                            <td>{{ $employeeData['hourly_wage'] }}</td>
                            <td>{{ $employeeData['total_salary'] }}</td>
                        </tr>
                            @php
                            $totalPayroll += $employeeData['total_salary'];
                            @endphp
                        </tr>
                        @endforeach
                        <!-- Display pagination links -->
                        <tr>
                            <th colspan="5">Maaşlar toplamı: {{ $totalPayroll }}</th>
                        </tr>
                    </tbody>
                    @php
                    $totalPayroll = 0; // Reset total payroll for the next group
                    @endphp
                @endforeach
            </table>
        </div>
        @endif
        @endforeach
    </div>
</div>
<script>
function filterByBranch() {
    let select = document.getElementById("branchSelect");
    let selectedBranch = select.value.toLowerCase();
    let branches = document.getElementsByClassName("branch-div");

    for (let i = 0; i < branches.length; i++) {
        let branch = branches[i];
        if (selectedBranch === "" || branch.id.toLowerCase() === selectedBranch) {
            branch.style.display = "block";
        } else {
            branch.style.display = "none";
        }
    }
}
</script>
</body>
</html>
