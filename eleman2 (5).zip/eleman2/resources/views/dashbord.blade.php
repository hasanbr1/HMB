<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/x.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/e26bec5e0a.js" crossorigin="anonymous"></script>
    <script>
       
$(document).ready(function() {
    const showDaily = document.getElementById('showDaily');
    const showMonthly = document.getElementById('showMonthly');
    const showlist = document.getElementById('showlist');
    function showView(viewType) {
        const dailyView = document.getElementById('daily-view');
        const monthlyView = document.getElementById('monthly-view');
        const listView = document.getElementById('list');
        if (viewType === 'daily') {
            dailyView.style.display = '';
            monthlyView.style.display = 'none';
            listView.style.display = 'none';
        } else if (viewType === 'monthly') {
            dailyView.style.display = 'none';
            monthlyView.style.display = '';
            listView.style.display = 'none';
        }
        else if(viewType === 'list'){
            dailyView.style.display = 'none';
            monthlyView.style.display = 'none';
            listView.style.display = '';
        }
    }

    showDaily.addEventListener('click', function() {
        showView('daily');
    });

    showMonthly.addEventListener('click', function() {
        showView('monthly');
    });
    showlist.addEventListener('click', function() {
        showView('list');
    });

    function parseDate(dateStr) {
        const parts = dateStr.split('-');
        return parts[0] + '/' + parts[1]; // Assuming YYYY-MM-DD format
    }

    const monthlyTotals = {};
    document.querySelectorAll('#daily-view tbody').forEach(tbody => {
        const dateText = tbody.previousElementSibling.querySelector('th').textContent;
        const monthYear = parseDate(dateText.split(' - ')[0]);

        tbody.querySelectorAll('tr').forEach(row => {
            const name = row.cells[0].textContent;
            const hourMinuteParts = row.cells[3].textContent.trim().split(':');
            const hours = parseInt(hourMinuteParts[0]);
            const minutes = parseInt(hourMinuteParts[1] || '0');

            if (!monthlyTotals[monthYear]) {
                monthlyTotals[monthYear] = {};
            }
            if (!monthlyTotals[monthYear][name]) {
                monthlyTotals[monthYear][name] = { totalMinutes: 0, salary: 0 };
            }
            monthlyTotals[monthYear][name].totalMinutes += (hours * 60 + minutes);
            monthlyTotals[monthYear][name].salary += parseFloat(row.cells[4].textContent);
        });
    });

    const monthlyBody = document.querySelector('#monthly-view tbody');
    monthlyBody.innerHTML = ''; // Clear existing rows

    Object.entries(monthlyTotals).forEach(([monthYear, names]) => {
        const headerRow = document.createElement('tr');
        headerRow.innerHTML = `<th colspan="4">${monthYear}</th>`;
        monthlyBody.appendChild(headerRow);

        Object.entries(names).forEach(([name, data]) => {
            const totalHours = Math.floor(data.totalMinutes / 60);
            const totalMinutes = data.totalMinutes % 60;
            const totalx =  (totalHours + totalMinutes/ 60) -260;
            const row = document.createElement('tr');
            if(totalx>0){
            row.innerHTML = `<td>${name}</td><td>${totalHours}h ${totalMinutes}m</td><td>${data.salary.toFixed(2)}</td><td style="color: blue;">${totalx}</td>`;
            monthlyBody.appendChild(row);
            }
            else{
                row.innerHTML = `<td>${name}</td><td>${totalHours}h ${totalMinutes}m</td><td>${data.salary.toFixed(2)}</td><td style="color: red;">${totalx}</td>`;
            monthlyBody.appendChild(row);
            }
        });
    });
});
</script>


</head>
<body>

   <!-- Sidebar -->
   
        <div id="logo" style="text-align:center;  background-color: black;"> 
    <br>
            <h1 style="color: orange; display:inline;">DÖNER</h1>
            <h1 style="color: yellow;  display:inline;">XL</h1>
        </div>
     
   <div id='head'>
   <div class="radio-inputs">
 
    <!-- Buttons to toggle views -->
    <label class="radio">
    <input type="radio" id="showDaily" onclick="showView('daily')" name="list">
    <span class="name">Günlük</span>
  </label>
    <label class="radio">
    <input type="radio" id="showMonthly" onclick="showView('monthly')" name="list">
    <span class="name">Aylık</span>
  </label>
    <label class="radio">
    <input type="radio" id="showlist" onclick="showView('list')" name="list">
    <span class="name">Bilgiler</span>
  </label>
  <label class="radio">
    <input type="radio" class="hamburger" aria-label="Toggle Menu" name="list">
    <span class="name" style=" color: white;">
    <i class="fa-solid fa-bars" style="color: #FFD43B;"></i>
        </span>
        </label>
</div>
</div>
<aside id="sidebar">
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="{{Route('ekle')}}">Yeni personel ekle</a></li>
                    <li><a href="{{Route('subev')}}">Yeni Şube ekle</a></li>
                   <li><a href="{{Route('duzeltmesi')}}">personel Düzeltme</a></li>
                   <li><a href="{{Route('gcduzeltmevi')}}">Giriş\Çıkış Düzeltme</a></li>
                   <li><a href="{{Route('subeler')}}">Şubeler</a></li>
                </ul>
            </nav>
        </aside>
    <!-- Daily view table -->
    <table id="daily-view" style="display: none;">
    @php
                        
                        $mt=(int)0;
                        $i=0;
                        $x='';
                        @endphp
        @foreach($elemans as $dayName => $daysEntries)
            @if($daysEntries->isNotEmpty())
                <thead>
                    <tr>
                        <th colspan="5">{{ $daysEntries->first()->dateg }} - {{ $daysEntries->first()->dates }}</th> 
                     
                     
                     
                       
                    
                    </tr>
                    <tr>
                        <th>Ad soyad</th>
                        <th>Giriş Saati</th>
                        <th>Çıkış Saati</th>
                        <th>Toplam Saat</th>
                        <th>Maaş</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($daysEntries as $eleman)
                    <tr>
                        <td>{{ $eleman->adi }}</td>
                        <td>{{ $eleman->formatted_giris }}</td>
                        <td>{{ $eleman->formatted_cikis }}</td>
                        <td class="hours"> 
                        @if($eleman->minutes_worked>=60)
                       {{ $eleman->minutes_worked/60}} :{{$eleman->minutes_worked%60  }}
                       @else
                      0: {{$eleman->minutes_worked}}
                            @endif
                        </td> <!-- Add class for JS targeting -->
                        <td >{{ $eleman->maas_total }}</td>
                        @php
                      
                        $mt+=(int)$eleman->maas_total;
                       
                        @endphp
                    </tr>
                    @endforeach
                   @php
                   
                   @endphp
                </tbody>
            @endif
        @endforeach

    </table>
 

    <!-- Monthly view table -->
    <table id="monthly-view" style="display: none;">
        <thead>
            <tr>
              
                <th>Ad soyad</th>
                <th>Toplam Saat</th>
                <th>Maaş</th>
                <th>aylık</th>
            </tr>
        </thead>
        <tbody id="monthly-summary">
            <!-- JavaScript will populate this -->
        </tbody>
    
    </table>

  <div id="list">

       <div class="18"><span style="color:#FFD43B;">Şubeler</span><i class="fa-solid fa-city fa-2xl" style="color: #FFD43B;"></i>
       <h4 style="color:#FFD43B;"> {{$sube}}</h4></div>
         
       <div><span style="color:#FFD43B;">Personeller</span><i class="fa-solid fa-address-book fa-2xl" style="color: #FFD43B;"></i>
            <h4 style="color:#FFD43B;">{{$say}}</h4></div>
        <div><span style="color:#FFD43B;">Aktiv</span><i class="fa-solid fa-check fa-2xl" style="color: #FFD43B;"></i>
        <h4 style="color:#FFD43B;">{{$aktiv}}  </h4></div>

        <div><span style="color:#FFD43B;">İzinli </span><i class="fa-sharp fa-solid fa-bed fa-2xl" style="color: #FFD43B;"></i>
        <h4 style="color:#FFD43B;">{{$izinli}}</h4></div>

        <div><span style="color:#FFD43B;">Bitirenler</span><i class="fa-solid fa-person-circle-check fa-2xl" style="color: #FFD43B;"></i>
        <h4 style="color:#FFD43B;">{{$biti}}</h4></div>

      

      
        
       </div>
        
        


       
   
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

    <script>
    $(document).ready(function() {
        $('.hamburger').click(function(event) {
            event.stopPropagation();  // Stop propagation to prevent closing when clicking inside the sidebar
            $('#sidebar').toggle('slow');
        });

        $(document).click(function(event) {
            if (!$(event.target).closest('#sidebar, .hamburger').length) {
                $('#sidebar').hide('slow');
            }
        });
    });
</script>

<footer>
{{$elemans->links()}}
</footer>
</body>
</html>

