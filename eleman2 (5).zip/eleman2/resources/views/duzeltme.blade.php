<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/duzeltme.css">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div id="logo"> 
            <h1  style= "color: orange;">DÖNER</h1>
    <h1 style=" color: yellow;">XL</h1>
</div>

    <div id="form">
      
        <form action="{{Route('duzeltmebilgi')}}" method="post">
            @csrf
         

            <label for="adi">Eleman seçin :</label>
            <select id="sube-select" name="adi">
    <option value="">Eleman Seç</option>
    @foreach ($uniqueNames as $name)
        <option value="{{$name}}">{{$name}}</option>
    @endforeach
</select>

            <button type="submit" name="btn2" >Seç</button>
            <button style=" margin-left: 0;  float: left;"><a href="{{Route('dash')}}">Geri</a></button>
            </form>
            <div id="con">
          
            <form action="{{Route('duzeltmebilgi')}}" method="post" id="f">
            @csrf
            <div id="eski">
             
    <label for="adi">Adı :</label>
    <input type="text" name="eadi" id="" readonly value="{{$eleman->adi ?? ''}}"><br>
    <label for="Kode">Şifre :</label>
    <input type="text" name="ekod" id=""readonly value="{{$eleman->kod  ?? ''}}"><br>
    <label for="">Maaş :</label>
    <input type="number" name="emaas" id="" readonly value="{{$eleman->maas  ?? ''}}"><br>
    
   
</div>

        <div id="yeni">
       
            <label for="adi"> Yeni Adı :</label>
            <input type="text" name="yadi" id=""><br>
            <label for="Kode">Yeni Şifre :</label>
            <input type="text" name="ykod" id=""><br>
            <label for="">Yeni Maaş :</label>
            <input type="number" name="ymaas" id=""><br>
            <button  type="submit" name="btn1" style=" margin-left: 0;" >kaydet</button>
            <div>
          
            </div>
            </form>
           
        </div>

        </div>
       
        </div>
    </body>
</html>
</body>
</html>