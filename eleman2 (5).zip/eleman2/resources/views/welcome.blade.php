<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="height=device-height, initial-scale=1.0">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/welcome.css">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div id="logo"> 
            <h1  style= "color: orange;">DÖNER</h1>
    <h1 style=" color: yellow;">XL</h1>
</div>
   
    <div id="form">
        <h3>Giriş Yap</h3>
       <form action="{{Route('giris')}}" method="post">
        @csrf
            <label for="adi">Adı :</label>
            <input type="text" name="adi" id=""><br>
            <label for="Kode">Şifre :</label>
            <input type="text" name="kod" id=""><br>
            <label for="remember">
          
        </label>
      
            <button type="submit">Giriş yap</button>
        </form>
        </div>
    </body>
</html>
</body>
</html>