<?php

namespace App\Models;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;

class Eleman extends Authenticatable implements AuthenticatableContract
{
    protected $fillable = [
        'adi',
        'kod',
        // other attributes that are mass assignable
        'remember_token',  // Add this line
    ];
    protected $dates = ['giris', 'cikis'];
    
}

