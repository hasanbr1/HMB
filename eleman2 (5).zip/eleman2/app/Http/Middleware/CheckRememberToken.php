<?php
namespace App\Http\Middleware;

use Closure;
use App\Models\Eleman;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Session;

class CheckRememberToken
{
    public function handle($request, Closure $next)
    {
        if (!Session::has('kod') && Cookie::has('remember')) {
            $rememberToken = Cookie::get('remember');
            $eleman = Eleman::where('remember_token', $rememberToken)->first();

            if ($eleman) {
                session(['kod' => $eleman->kod]);
            }
        }

        return $next($request);
    }
}
