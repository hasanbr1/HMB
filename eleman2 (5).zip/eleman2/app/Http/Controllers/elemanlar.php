<?php

namespace App\Http\Controllers;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\Models\Eleman;
use App\Models\sube;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
class elemanlar extends Controller

{
    /**
     * Display a listing of the resource.
     *
     * 
     */public function index(Request $request)
{
    $elemans = Eleman::orderBy('giris', 'desc') // Sort entries by 'giris' in descending order
        ->whereYear('giris', '!=', 1999)
        ->paginate(20);

    $transformedData = $elemans->getCollection()
        ->map(function ($eleman) {
            $eleman->sube;
            if ($eleman->giris && $eleman->cikis) {
                $eleman->formatted_giris = Carbon::parse($eleman->giris)->format('H:i');
                $eleman->formatted_cikis = Carbon::parse($eleman->cikis)->format('H:i');
                $eleman->dateg = Carbon::parse($eleman->giris)->format('Y-m-d');
                $eleman->dates = Carbon::parse($eleman->cikis)->format('Y-m-d');
                $eleman->minutes_worked = Carbon::parse($eleman->giris)->diffInMinutes(Carbon::parse($eleman->cikis));
                $eleman->maas_total = ($eleman->maas / 60) * $eleman->minutes_worked;
            } elseif ($eleman->giris) {
                $eleman->formatted_giris = Carbon::parse($eleman->giris)->format('H:i');
                $eleman->formatted_cikis = 'N/A';
                $eleman->dateg = 'N/A';
                $eleman->dates = 'N/A';
                $eleman->hours_worked = 0;
                $eleman->maas_total = 0;
            }
            return $eleman;
        });
        $sube=sube::count('id');
        $elemans->setCollection($transformedData->groupBy('dateg'));
        $say = Eleman::where('giris', '1999-12-12 00:00:00')->count();
        $aktiv = Eleman::whereDate('giris', today())->where('cikis',null)->count();
        $biti = Eleman::whereDate('giris', today())->whereNotNull('cikis')->count();
        $izinli=$say-$aktiv-$biti;



    $request->session()->put('elemans', $elemans);
    return view('dashbord', compact('elemans') ,['sube' => $sube ,'say' => $say ,'aktiv'=>$aktiv , 'biti' =>$biti , 'izinli' => $izinli]);
}


public function subeler(Request $request)
{

  $sube=new sube();
  $sube->sube=request('sube');
  $sube->save();
  return back();

}
public function showSelectSube()
{
// Fetching all entries from the 'sube' table
$subes = Sube::all();

// Passing data directly to the view
return view('bilgiler', compact('subes' , $subes));
}


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * 
     */
    public function store(Request $request)
    {
    
       $eleman=new Eleman();
       $eleman->adi=request('adi');
       $eleman->kod=request('kod');
       $eleman->maas=request('maas');
       $eleman->giris='1999-12-12 00:00:00';
       $eleman->sube=null;
       $eleman->cikis='1999-12-12 00:00:00';
      

       if ( $request->input('admin') == '1'){
        $eleman->is='admin';
       }
       else{
        $eleman->is='isci';
       }
       
       $eleman->save();
       
       return back();
    
    }
    public function giris(Request $request)
{
    $adi = $request->input('adi');
    $kod = $request->input('kod');
    $remember = $request->has('remember');
    $eleman = Eleman::where('adi', $adi)->where('kod', $kod)->first();

    if ($eleman) {
        // Check if we should remember the user
        if ($remember) {
            $rememberToken = Hash::make(bin2hex(random_bytes(10)));
            $eleman->update(['remember_token' => $rememberToken]);
            Cookie::queue('remember', $rememberToken, 43200); // Expires in 30 days
        }

        if ($eleman->is == 'admin') {
            session(['kod' => $eleman->kod]);
            return redirect('dashbord');
        } else {
            session(['kod' => $eleman->kod]);
            return redirect('bilgiler');
        }
    } else {
        return back()->withErrors(['message' => 'Invalid credentials']);
    }
}
    public function indexbilgi(Request $request)
    {
        $kod = session('kod');
     
        $userEntries = Eleman::where('kod', $kod)->orderBy('giris', 'desc')  
        
            ->get()
            ->map(function ($eleman) {
                $eleman->adi;
                    $eleman->kod;
                if ($eleman->giris && $eleman->cikis) {
                  
                    $eleman->formatted_giris = Carbon::parse($eleman->giris)->format('H:i');
                    $eleman->formatted_cikis = Carbon::parse($eleman->cikis)->format('H:i');
                    $eleman->dateg = Carbon::parse($eleman->giris)->format('Y-m-d');
                    $eleman->dates = Carbon::parse($eleman->cikis)->format('Y-m-d');
                    // Calculate total time worked in minutes
                    $eleman->minutes_worked = Carbon::parse($eleman->giris)->diffInMinutes(Carbon::parse($eleman->cikis));
                    // Calculate total salary based on the minutes worked
                    $eleman->maas_total = ($eleman->maas / 60) * $eleman->minutes_worked;
                } elseif($eleman->giris){
                  
                    $eleman->formatted_giris = Carbon::parse($eleman->giris)->format('H:i');
                    $eleman->formatted_cikis = 'N/A';
                    $eleman->dateg = 'N/A';
                    $eleman->dates = 'N/A';
                    $eleman->hours_worked = 0;
                    $eleman->maas_total=0;
                }
                else{

                    $eleman->formatted_giris = 'izinli';
                    $eleman->formatted_cikis = 'izinli';
                    $eleman->dateg = 'izinli';
                    $eleman->dates = 'izinli';
                    $eleman->hours_worked = 0;
                    $eleman->maas_total=0;
                }
             
                return $eleman;
              
            })
            ->groupBy('dateg'); 
    
            $subes = Sube::pluck('sube'); 

    session()->put('subes', $subes);

          
    
        return view('bilgiler', compact('userEntries'));
    }
    
    
    public function sift(Request $request)
    {
         if ($request->has('shiftStartButton')) {
            $request->validate([
                'sube' => 'required',  // Making 'name' field required
            ]);
        $adi = $request->input('adi');
        $kod = $request->input('kod');
        $sube=$request->input('sube');
        $eleman = new Eleman();
        $eleman->adi=$adi;
        $eleman->kod=$kod;
            $eleman->giris=now();
            $eleman->sube=$sube;
            $eleman->cikis=null;
            $elemans = Eleman::select('maas')->where('adi', $adi)
            ->where('kod', $kod)
            ->first();
            $eleman->maas = $elemans->maas;
            $eleman->save();
            return back()->with('status', 'true');

    
       
    }
    if ($request->has('shiftEndButton')) {
        $adi = $request->input('adi');
        $kod = $request->input('kod');
        $sube = $request->input('sube');
        
        $eleman = Eleman::where('adi', $adi)
                        ->where('kod', $kod)
                        ->where('cikis', null)
                        ->first();
        
        if ($eleman) {
            $eleman->cikis = now();
            $eleman->save();
            $status = "false";
            return back();
    }
   
}
    }

    
  
    

 

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     *
     */
    public function subelerviwe()
    {
        $elements = Eleman::orderBy('giris', 'desc')->get();
        $groupedResults = $elements->groupBy(['sube', function($item) {
            return $item->giris->format('Ym');
        }]);
    
        $results = $groupedResults->map(function ($branches) {
            return $branches->map(function ($employees) {
                return $employees->groupBy('adi')->map(function ($group) {
                    $totalHours = $group->sum(function ($employee) {
                        return $employee->giris->diffInHours($employee->cikis);
                    });
                    $totalDays = $group->count();
                    $totalSalary = $group->sum(function ($employee) {
                        return $employee->giris->diffInHours($employee->cikis) * $employee->maas;
                    });
    
                    return [
                        'total_hours' => $totalHours,
                        'total_days' => $totalDays,
                        'total_salary' => $totalSalary,
                        'hourly_wage' => $group->first()->maas,
                    ];
                });
            });
        });
    
        return view('subeler', ['branches' => $results]);
    }
    
    
    
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return 
     */
    public function update(Request $request, $id)
    {
       $adi=request('adi');
       $kod=request('kod');
       $eleman = Eleman::where('eadi', $adi)->where('ekod', $kod)->first();
       $yadi=request('yadi');
       $ykod=request('ykod');
       $ymaas=request('ymaas');
       if($yadi != null)
       $eleman->adi=$yadi;
       if($ykod != null)
       $eleman->kod=$ykod;
       if($ymaas != null)
       $eleman->maas=$ymaas;

       return back();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * 
     */
    public function getadi()
    {
      
    }
    public function elemanb(Request $request)
    {
        // Define $uniqueNames at the top so it's always set for any view return
        $uniqueNames = Eleman::select('adi')->distinct()->pluck('adi');
    
        // Check for button 'btn2' submission
        if ($request->has('btn2')) {
            $eleman = Eleman::where('adi', $request->adi)->first(); // Fetch the first record matching the 'adi'
            return view('duzeltme', ['uniqueNames' => $uniqueNames, 'eleman' => $eleman]);
        }
        // Check for button 'btn1' submission
        elseif ($request->has('btn1')) {
            $adi = $request->input('eadi');
            $kod = $request->input('ekod');
            $eleman = Eleman::where('adi', $adi)->where('kod', $kod)->first();
    
            $yadi = request('yadi');
            $ykod = request('ykod');
            $ymaas = request('ymaas');
    
            if ($yadi != null) $eleman->adi = $yadi;
            if ($ykod != null) $eleman->kod = $ykod;
            if ($ymaas != null) $eleman->maas = $ymaas;
    
            if ($yadi != null || $ykod != null || $ymaas != null) {
                $eleman->save();
            }
            return back();
        }
        else {
            // Return view with uniqueNames for default access
            return view('duzeltme')->with('uniqueNames', $uniqueNames);
        }
    }
    public function gcduzeltme(Request $request)
    {
        $uniqueElements = Eleman::select('adi', 'giris')->distinct()->get();



        if ($request->has('btn2')) {
            $eleman = $request->input('eleman');
                list($adi, $giris) = explode('|', $eleman);  // Split the value using the delimiter
                $gcikis = Eleman::where('adi', $adi)->where('giris', $giris)->first(); // Query based on both
                return view('gcduzeltme', [ 'uniqueElements' => $uniqueElements ,'gcikis' =>  $gcikis]);
        }

        elseif ($request->has('btn1')) {
            $adi = $request->input('adi');
            $ecikis = $request->input('ecikis');
            $giris = $request->input('giris');
            $eleman = Eleman::where('adi', $adi)->where('giris', $giris)->first();
    
            $ycikis = request('ycikis');
            $eleman->cikis=$ycikis;
            $eleman->save();

            return back();
        }
        elseif ($request->has('btn3')) {
            $adi = $request->input('adi');
            $ecikis = $request->input('ecikis');
            $giris = $request->input('giris');
            $eleman = Eleman::where('adi', $adi)->where('giris', $giris)->first();
            $eleman->delete();


            return back();
        }
        else {
            // Return view with uniqueNames for default access
            return view('gcduzeltme', [ 'uniqueElements' => $uniqueElements ]);
        }
    }

    public function muhasabe()
    {
        $elements = Eleman::orderBy('giris', 'desc')->get();

        $groupedResults = $elements->groupBy(function ($item) {
            return $item->giris->format('Y-m'); // Group by year and month
        })->map(function ($group) {
            return $group->groupBy('adi')->map(function ($subGroup) {
                $daysWorked = 0;
                $totalDuration = 0;
                $latestMaas = $subGroup->first()->maas; // Assume the first item after ordering has the latest 'maas'
    
                foreach ($subGroup as $item) {
                    $dailyHours = $item->giris->diffInMinutes($item->cikis) / 60;
                    $totalDuration += $dailyHours;
    
                    // Count as a full day only if more than 6 hours were worked that day
                    if ($dailyHours >= 6) {
                        $daysWorked++;
                    }
                }
    
                // Convert totalDuration to total hours and minutes for display
                $hours = intdiv((int)($totalDuration * 60), 60);
                $minutes = ($totalDuration * 60) % 60;
    
                return [
                    'hours' => sprintf('%02d:%02d', $hours, $minutes),
                    'days_worked' => $daysWorked,
                    'maas' => $latestMaas // Include the latest 'maas' for the month
                ];
            });
        });
        return view( 'muhasabe' ,['workDays'=> $groupedResults]);
    }
}
    
