<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Monthly Hours and Salaries</title>
    <link rel="stylesheet" href="css/x.css">
</head>
<body>
    <style>
        body{
            text-align: center;
        }
    </style>
<div class="container mt-5">

            <h1 style="color: orange; display: inline">DÖNER</h1>
            <h1 style="color: yellow;  display: inline">XL</h1>
      
    <select id="branchSelect" onchange="filterByBranch()" style="margin-bottom: 20px; width: 100%;">
        <option value="">Select Branch</option>
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sube => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($sube != null): ?>
                <option value="<?php echo e($sube); ?>"><?php echo e($sube); ?></option>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <div id="branchesContainer">
        <?php
        $totalPayroll = 0;
        ?>
        <?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sube => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($sube != null): ?>
        <div class="branch-div" id="<?php echo e($sube); ?>" style="display: none;">
            <table class="table table-bordered">
                <thead class="branch-header">
                    <tr>
                        <th colspan="5" style="background: red;"><?php echo e($sube); ?></th>
                    </tr>
                </thead>
                <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year_month => $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <thead>
                        <tr>
                            <th colspan="5"><?php echo e($year_month); ?></th>
                        </tr>
                        <tr>
                            <th>Eleman Adı</th>
                            <th>Saat toplamı</th>
                            <th>Gün toplamı</th>
                            <th>Saat başına Maas</th>
                            <th>Maas toplamı</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employeeName => $employeeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <tr>
                            <td><?php echo e($employeeName); ?></td>
                            <td><?php echo e($employeeData['total_hours']); ?></td>
                            <td><?php echo e($employeeData['total_days']); ?></td>
                            <td><?php echo e($employeeData['hourly_wage']); ?></td>
                            <td><?php echo e($employeeData['total_salary']); ?></td>
                        </tr>
                            <?php
                            $totalPayroll += $employeeData['total_salary'];
                            ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- Display pagination links -->
                        <tr>
                            <th colspan="5">Maaşlar toplamı: <?php echo e($totalPayroll); ?></th>
                        </tr>
                    </tbody>
                    <?php
                    $totalPayroll = 0; // Reset total payroll for the next group
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<script>
function filterByBranch() {
    let select = document.getElementById("branchSelect");
    let selectedBranch = select.value.toLowerCase();
    let branches = document.getElementsByClassName("branch-div");

    for (let i = 0; i < branches.length; i++) {
        let branch = branches[i];
        if (selectedBranch === "" || branch.id.toLowerCase() === selectedBranch) {
            branch.style.display = "block";
        } else {
            branch.style.display = "none";
        }
    }
}
</script>
</body>
</html>
<?php /**PATH C:\Users\msi\eleman2\resources\views/subeler.blade.php ENDPATH**/ ?>