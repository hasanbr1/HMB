<?php
function calculateAdditionalHours($daysWorked) {
    $days = (int)substr($daysWorked, 0, 2);
    if ($days >= 7) {
        return 10;
    } elseif ($days >= 14) {
        return 20;
    } elseif ($days >= 21) {
        return 30;
    } elseif ($days >= 26) {
        return 40;
    } else {
        return 0;
    }
}

function initialSalary($hours, $rate, $daysWorked) {
    list($hr, $min) = explode(':', $hours);
    $totalHours = $hr + $min / 60;
    $additionalHours = calculateAdditionalHours($daysWorked);
    return number_format(($rate * ($totalHours + $additionalHours)), 2, '.', '');
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Work Days Summary</title>
    <link href="css/x.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5"style="text-align:center;">
     <h1 style="color: orange; display:inline;">DÖNER</h1>
            <h1 style="color: yellow;  display:inline;">XL</h1>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>personel Ad soyadı</th>
                    <th>mesai toplamı</th>
                    <th>Gün toplamı</th>
                    <th>izin günleri</th>
                    <th>Saatlık ücret</th>
                    <th>Avans</th>
                    <th>Tutanak</th>
                    <th>Prim</th>
                    <th>Maaş</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $workDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthYear => $employees): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($monthYear !='1999-12'): ?>
                    <tr>
                        <th colspan="9"><?php echo e($monthYear); ?></th>
                    </tr>
                    <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                        <tr>
                            <td><?php echo e($name); ?></td>
                            <td data-hours="<?php echo e($data['hours']); ?>"><?php echo e($data['hours']); ?></td>
                            <td><?php echo e($data['days_worked']); ?></td>
                            <td><?php echo e((substr($data['days_worked'], 0, 2)-30)*-1); ?></td>
                            <td><?php echo e($data['maas']); ?></td>
                            <td><input type="number" class="avans" oninput="updateSalary(this)"></td>
                            <td><input type="number" class="tutanak" oninput="updateSalary(this)"></td>
                            <td><input type="number" class="prim" oninput="updateSalary(this)"></td>
                        <!-- In your Blade file inside the table -->
<td class="maas" data-baserate="<?php echo e($data['maas']); ?>" data-hours="<?php echo e($data['hours']); ?>" data-additional-hours="<?php echo e(calculateAdditionalHours($data['days_worked'])); ?>"><?php echo e(initialSalary($data['hours'], $data['maas'], $data['days_worked'])); ?></td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
    function updateSalary(element) {
        var row = element.closest('tr');
        var baseRate = parseFloat(row.querySelector('.maas').getAttribute('data-baserate'));
        var hoursMinutes = row.querySelector('[data-hours]').getAttribute('data-hours').split(':');
        var additionalHours = parseFloat(row.querySelector('.maas').getAttribute('data-additional-hours'));
        var totalHours = parseFloat(hoursMinutes[0]) + parseFloat(hoursMinutes[1]) / 60 + additionalHours;
        var avans = parseFloat(row.querySelector('.avans').value) || 0;
        var tutanak = parseFloat(row.querySelector('.tutanak').value) || 0;
        var prim = parseFloat(row.querySelector('.prim').value) || 0;

        // Calculate base salary
        var baseSalary = baseRate * totalHours;
        // Calculate final salary after adjustments
        var finalSalary = baseSalary - avans - tutanak + prim;

        // Update the maas cell in the row
        row.querySelector('.maas').textContent = finalSalary.toFixed(2);
    }
</script>

</body>
</html>
<?php /**PATH C:\Users\msi\eleman2\resources\views/muhasabe.blade.php ENDPATH**/ ?>