<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/eleman.css">

        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
        <div id="logo"> 
            <h1  style= "color: orange;">DÖNER</h1>
    <h1 style=" color: yellow;">XL</h1>
</div>

    <div id="form">
        <h3>yeni eleman</h3>
        <form action="<?php echo e(Route('ekleme')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="adi">Adı :</label>
            <input type="text" name="adi" id=""><br>
            <label for="Kode">Şifre :</label>
            <input type="text" name="kod" id=""><br>
            <label for="Kode">Maaş :</label>
            <input type="number" name="maas" id=""><br>
            <div id="box">
            <label for="agree">Admin :</label>
                 <input type="checkbox" id="agree" name="admin" value="1">
        </div>
            <button type="submit" >kaydet</button>
            <button style=" margin-left: 0;  float: left;"><a href="<?php echo e(url()->previous()); ?>" id="geri">Geri</a></button>
        </form>
        </div>
    </body>
</html>
</body>
</html><?php /**PATH C:\Users\msi\eleman2\resources\views/eleman.blade.php ENDPATH**/ ?>