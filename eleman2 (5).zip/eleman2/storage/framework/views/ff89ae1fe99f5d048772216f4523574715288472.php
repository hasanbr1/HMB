<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/duzeltme.css">

        <style>
           button {
                margin-left: 6%;
            }
            body{
                margin: 0%;
            }
            #form{
               width: 90%;
            }
            @media (min-width: 768px) {
    #form {
        flex-direction: column;
        width: 35%; /* Increase width for smaller screens */
        height: auto; /* Make height auto for better flexibility */
        margin-left: 30%;
    }
    button {
              
            }
}
        </style>
    </head>
    <body class="antialiased">


    <div id="form">
      
        <form action="<?php echo e(Route('gcduzeltme')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <label for="eleman-select">Eleman ve Tarih Seçin:</label>
<select id="eleman-select" name="eleman">
    <option value="">Eleman ve Tarih Seç</option>
    <?php $__currentLoopData = $uniqueElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($element->giris != '1999-12-12 00:00:00'): ?>
        <option value="<?php echo e($element->adi); ?>|<?php echo e($element->giris); ?>"><?php echo e($element->adi); ?> - <?php echo e($element->giris); ?></option>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
            <button type="submit" name="btn2" >Seç</button>
            <button ><a href="<?php echo e(Route('dash')); ?>">Geri</a></button>
            </form>
            <div id="con">
          
            <form action="<?php echo e(Route('gcduzeltme')); ?>" method="post" >
            <?php echo csrf_field(); ?>

    <label for="adi">çıkış tarihi:</label>
    <input type="text" name="ecikis" id="" readonly value="<?php echo e($gcikis->cikis ?? 'çıkış yapılmadı'); ?>">
    <label for="adi">Adi:</label>
     <input type="text" name="adi" id="" value="<?php echo e($gcikis->adi ?? ''); ?> ">
     <label for="adi">giriş tarihi:</label>
     <input type="text" name="giris" id="" value="<?php echo e($gcikis->giris ?? ''); ?>" >
     <label for="adi"> Yeni çıkış tarihi:</label>
     <input type="datetime-local"  name="ycikis" id="">

    <button type="submit" name="btn1" >Kaydet</button>
    <button type="submit" name="btn3" style="float:left;" >Sil</button>
            </form>
           
        </div>

        </div>
       
        </div>
    </body>
    
</html>
</body>
</html><?php /**PATH C:\Users\msi\eleman2\resources\views/gcduzeltme.blade.php ENDPATH**/ ?>