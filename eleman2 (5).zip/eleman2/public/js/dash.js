

    $('.hamburger').click(function() {
        $('#sidebar').toggle('slow');
    });


    document.addEventListener("DOMContentLoaded", function () {
        const showDaily = document.getElementById('showDaily');
        const showMonthly = document.getElementById('showMonthly');
        const dailyTable = document.getElementById('dailyTable');
        const monthlyTable = document.getElementById('monthlyTable');
    
        // Toggle view buttons
        showDaily.addEventListener('click', function() {
            dailyTable.style.display = '';
            monthlyTable.style.display = 'none';
        });
        showMonthly.addEventListener('click', function() {
            dailyTable.style.display = 'none';
            monthlyTable.style.display = '';
        });
    
        // Calculate monthly totals
        const monthlyTotals = {};
        document.querySelectorAll('#dailyTable tbody').forEach(tbody => {
            tbody.querySelectorAll('tr').forEach(row => {
                const name = row.cells[0].textContent;
                const hours = parseFloat(row.cells[row.cells.length - 1].textContent);
                const date = tbody.previousElementSibling.querySelector('th').textContent.split('-')[1].trim();
                const monthYear = new Date(date).toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });
    
                if (!monthlyTotals[monthYear]) {
                    monthlyTotals[monthYear] = {};
                }
                if (!monthlyTotals[monthYear][name]) {
                    monthlyTotals[monthYear][name] = 0;
                }
                monthlyTotals[monthYear][name] += hours;
            });
        });
    
        // Display monthly totals
        const monthlyBody = document.querySelector('#monthlyTable tbody');
        Object.entries(monthlyTotals).forEach(([month, names]) => {
            Object.entries(names).forEach(([name, hours]) => {
                const row = document.createElement('tr');
                row.innerHTML = `<td>${month}</td><td>${name}</td><td>${hours.toFixed(2)}</td>`;
                monthlyBody.appendChild(row);
            });
        });
    });